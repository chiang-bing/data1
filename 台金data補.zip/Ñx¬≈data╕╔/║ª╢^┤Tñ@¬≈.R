rm(list=ls())
library(magrittr) # %>%
library(plyr) # ddply
library(dplyr) # group_by
library(fTrading)
library(DBI) 
library(RSQLite)
library(data.table)
setwd('C:/Users/f129441027/Desktop/台金data補')
mydb <- dbConnect(RSQLite::SQLite(), "C:/Users/f129441027/Desktop/分K/_1min.sqlite")

index_tx = dbReadTable(mydb,"TSE9")
index_fx = dbReadTable(mydb,"TSEFI9")
index_tx=index_tx[index_tx$時間>="09:00:00"&index_tx$時間<="13:29:00",]
index_fx=index_fx[index_fx$時間>="09:00:00"&index_fx$時間<="13:29:00",]

index_tx=index_tx[,c(1,2,6)]
index_fx=index_fx[,c(1,2,6)]

index_fx$時間 = gsub(":", "", index_fx$時間)
index_fx$時間 = gsub(" ", "", index_fx$時間)
index_tx$時間 = gsub(":", "", index_tx$時間)
index_tx$時間 = gsub(" ", "", index_tx$時間)

index_20 = merge(index_tx, index_fx, by=c("日期", "時間"), all.x = T)
colnames(index_20)=c("Date","Time","TXF","FX")
index_20 =index_20[order(as.Date(index_20$Date), index_20$Time), ]

index_20$Time = gsub(":", "", index_20$Time)
index_20$Time = gsub(" ", "", index_20$Time)

index_20$Time = as.numeric(index_20$Time)
index_20$Date = gsub("-", "", as.character(as.Date(index_20$Date)))

# 除息
point = read.csv("point_use_202010.csv")
colnames(point) = c("Date","TXP","FXP")
# txpoint$Date=as.Date(txpoint$Date)
# mer=merge(mer,txpoint,by='Date',all.x=T)
# mer$preTX=mer$TX+mer$TXup.
index_20=merge(index_20,point,by='Date',all.x=T)

index_20$TXF=index_20$TXF-index_20$TXP
index_20$FX=index_20$FX-index_20$FXP
index_20 = index_20[order(index_20$Date, index_20$Time), ]



TXF = dbReadTable(mydb,"TXF1")
FXF = dbReadTable(mydb,"FXF1")
colnames(TXF)=c("Date","Time","Open","High","Low","Close","Vol")
colnames(FXF)=c("Date","Time","Open","High","Low","Close","Vol")

TXF$Time = gsub(":", "", TXF$Time)
TXF$Time = gsub(" ", "", TXF$Time)
FXF$Time = gsub(":", "", FXF$Time)
FXF$Time = gsub(" ", "", FXF$Time)
mer = merge(TXF, FXF, by=c("Date","Time"), all=T)
mer = mer[order(as.Date(mer$Date), mer$Time), ]

mer$Date = gsub("-", "", as.Date(mer$Date))

startdate = 20150101


mer = mer[mer$Date>=startdate, ]


mer = mer[order(mer$Date, mer$Time),]
rownames(mer) = NULL
mer$fx_dif_value =  mer$Close.x*200*1-mer$Close.y*2*1000

settle = read.csv("C:/Users/f129441027/Desktop/除息/結算.csv")
settle = settle[order(settle$Date),]
settle$Date = gsub("-", "", as.character(as.Date(settle$Date)))
settle_date = settle$Date
settle_date = c(settle_date)
settle = data.frame(Date=settle$Date[settle$Date>=startdate])

##################################
daydf = mer %>% group_by(Date) %>% dplyr::summarise(txdayOpen = mean(Close.x[9:16]),fxdayOpen = mean(Close.y[9:16]))
mer = merge(mer, daydf, all.x=T)

mer$Time = as.numeric(mer$Time)
mer = mer[mer$Time>=90000 & mer$Time<=134400, ]
mer = merge(mer, index_20, by=c("Date", "Time"), all.x = T)
mer = mer[order(mer$Date, mer$Time),]

rownames(mer) = NULL
mer=mer[complete.cases(mer$Open.x),]
mer$speed = ((mer$Close.x-mer$txdayOpen)/mer$txdayOpen)-((mer$Close.y-mer$fxdayOpen)/mer$fxdayOpen)       ####記得把價差轉正

Dayreport = c()
for(grp in unique(mer$Date)){
  
  subs = dplyr:: filter(mer,Date == grp)
  Dayreport = rbind(Dayreport, list(grp,
                                    mean(subs$fx_dif_value[2:4]),
                                    subs$fx_dif_value[270],
                                    mean(subs$fx_dif_value[2:4])))
}

colnames(Dayreport) = c("Date", "OpenD", "CloseD", "outOpenD")
Dayreport = as.data.frame(Dayreport)
Dayreport$OpenD = as.numeric(as.character(Dayreport$OpenD))
Dayreport$CloseD = as.numeric(as.character(Dayreport$CloseD))
Dayreport$outOpenD = as.numeric(as.character(Dayreport$outOpenD))
Dayreport$LS = ifelse(Dayreport$CloseD - Dayreport$OpenD > 0, 1, 0)


mer$txdiff = ((mer$Close.x - mer$TXF) / mer$TXF)
mer$fxdiff = ((mer$Close.y - mer$FX) / mer$FX)
mer$tediff = mer$txdiff - mer$fxdiff
rownames(mer) = NULL
mer = mer[mer$Time <= 132900, ]
laclose = mer %>% group_by(Date) %>% slice(n())
laclose = laclose[,c(1,13)]
laclose$fx_dif_value=shift(laclose$fx_dif_value)
colnames(laclose)=c("Date","lavalue")
mer =left_join(mer,laclose,by="Date")
mer = mer[!is.na(mer$lavalue),]
#####################################################################
tax = 1200*2
pos = data.frame()
daily_profit=data.table()
hold = 0
maxnet = 0
minnet = 0
firsts = as.numeric(table(mer$Date)[1])
tradedate_B = 20181218
tradedate_S = 20181218
speed_thr = 0.001
netlimit=15000


for (nr in 271:nrow(mer)) {
  
  if(abs(hold) == 0 & mer$Time[nr]>=90100 & mer$Time[nr]<= 132400){
    
    # case1
    if(tradedate_B!=mer$Date[nr] & mer$speed[nr]>speed_thr & mer$speed[nr-1]>speed_thr & mer$tediff[nr]<0 & mer$tediff[nr-1]<0){
      hold = 1
      BS = "BSpread"
      holdtx = mer$Close.x[nr]
      holdfx = -mer$Close.y[nr]
      tradedate_B = mer$Date[nr]
      lastprice=mer$fx_dif_value[nr]
      daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_in",-tax)),use.names=F)
      
      pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_in", "進場", hold,
                            0, 0,
                            holdtx, holdfx, 0))
      next
      
      # case1
    }else if(tradedate_S!=mer$Date[nr] & mer$speed[nr]<((-1)*speed_thr) & mer$speed[nr-1]<((-1)*speed_thr) & mer$tediff[nr]>0 & mer$tediff[nr-1]>0 ){
      
      hold = -1
      BS = "SSpread"
      holdtx = -mer$Close.x[nr]
      holdfx =  mer$Close.y[nr]
      tradedate_S = mer$Date[nr]
      lastprice=mer$fx_dif_value[nr]
      daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_in",-tax)),use.names=F)
      
      pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_in", "進場", hold,
                            0, 0,
                            holdtx, holdfx, 0))
      next
      
    }
  }
  
  if(abs(hold) == 1){
    
    whdayreport = which(mer$Date[nr] == Dayreport$Date)
    
    if(BS == "BSpread"){
      
      net = round(((mer$Close.x[nr] - holdtx)*200*1) + ((-holdfx - mer$Close.y[nr])*1000*2)) - tax
      maxnet = max(maxnet, net)
      minnet = min(minnet, net)

      if(mer$Time[nr]>=90100 & mer$Time[nr]<= 132900)
      {
        if(mer$Date[nr] != tradedate_B & mer$Time[nr]>90300 & Dayreport$LS[whdayreport - 1] == 1 & Dayreport$outOpenD[whdayreport] < Dayreport$CloseD[whdayreport-1]-7000){
          hold = 0
          net = round(((mer$Close.x[nr] - holdtx)*200*1) + ((-holdfx - mer$Close.y[nr])*1000*2)) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","case2", hold,
                                maxnet, minnet,
                                -mer$Close.x[nr], -mer$Close.y[nr], net))
          
          if(mer$Date[nr] == tradedate_B)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr])),use.names=F)
          }
          tradedate_B = mer$Date[nr]
          maxnet = 0
          minnet = 0
          lastprice = 0
          net = 0
          BS = ""
          next
        }
        
        
        if(mer$speed[nr]<((-1)*speed_thr) & mer$speed[nr-1]<((-1)*speed_thr)& mer$tediff[nr]>0 & mer$tediff[nr-1]>0 & mer$Time[nr]<= 132400)
        {
          hold = 0
          net = round(((mer$Close.x[nr] - holdtx)*200*1) + ((-holdfx - mer$Close.y[nr])*1000*2)) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","case3", hold,
                                maxnet, minnet,
                                -mer$Close.x[nr], mer$Close.y[nr], net))
          
          if(mer$Date[nr] == tradedate_B)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr])),use.names=F)
          }
          maxnet = 0
          minnet = 0
          lastprice = 0
          net = 0
          BS = ""
          next
        }
        
        if(maxnet>=30000 & net <= (maxnet-netlimit)){
          hold = 0
          net = round(((mer$Close.x[nr] - holdtx)*200*1) + ((-holdfx - mer$Close.y[nr])*1000*2)) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","case5", hold,
                                maxnet, minnet,
                                -mer$Close.x[nr], mer$Close.y[nr], net))
          
          if(mer$Date[nr] == tradedate_B)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr])),use.names=F)
          }
          tradedate_B = mer$Date[nr]
          maxnet = 0
          minnet = 0
          lastprice = 0
          net = 0
          BS = ""
          next
        }
        
        if(net < (-30000)){
          hold = 0
          net = round(((mer$Close.x[nr] - holdtx)*200*1) + ((-holdfx - mer$Close.y[nr])*1000*2)) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","case4", hold,
                                maxnet, minnet,
                                -mer$Close.x[nr], mer$Close.y[nr], net))
          
          if(mer$Date[nr] == tradedate_B)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr])),use.names=F)
          }
          tradedate_B = mer$Date[nr]
          maxnet = 0
          minnet = 0
          lastprice = 0
          net = 0
          BS = ""
          next
        }
      }
      if(mer$Time[nr]== 132900 & !is.element(mer$Date[nr],settle_date))
      {
        if(mer$Date[nr] == tradedate_B)
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice)),use.names=F)
          
        }
        else
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr])),use.names=F)
        }
      }
    }
    
    if(BS == "SSpread")
    {
      
      net = round(((-holdtx - mer$Close.x[nr])*200*1) + ((mer$Close.y[nr] - holdfx)*1000*2)) - tax
      maxnet = max(maxnet, net)
      minnet = min(minnet, net)

      if(mer$Time[nr]>=90100 & mer$Time[nr]<= 132900)
      {
        if(mer$Date[nr] != tradedate_S & mer$Time[nr]>90300 & Dayreport$LS[whdayreport - 1] == 0 & Dayreport$outOpenD[whdayreport]>Dayreport$CloseD[whdayreport-1]+7000){
          hold = 0
          net = round(((-holdtx - mer$Close.x[nr])*200*1) + ((mer$Close.y[nr] - holdfx)*1000*2)) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","case2", hold,
                                maxnet, minnet,
                                mer$Close.x[nr], -mer$Close.y[nr], net))
          
          if(mer$Date[nr] == tradedate_S)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr])),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr])),use.names=F)
          }
          tradedate_S = mer$Date[nr]
          maxnet = 0
          minnet = 0
          lastprice = 0
          net = 0
          BS = ""
          next
        }
        
        if(maxnet >= 30000 & net <= (maxnet-netlimit)){
          hold = 0
          net = round(((-holdtx - mer$Close.x[nr])*200*1) + ((mer$Close.y[nr] - holdfx)*1000*2)) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","case5", hold,
                                maxnet, minnet,
                                mer$Close.x[nr], -mer$Close.y[nr], net))
          
          if(mer$Date[nr] == tradedate_S)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr])),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr])),use.names=F)
          }
          tradedate_S = mer$Date[nr]
          maxnet = 0
          minnet = 0
          lastprice = 0
          net = 0
          BS = ""
          next
        }
        
        if(mer$speed[nr]>speed_thr & mer$speed[nr-1]>speed_thr & mer$tediff[nr]<0 & mer$tediff[nr-1]<0 & mer$Time[nr]<= 132400){
          hold = 0
          net = round(((-holdtx - mer$Close.x[nr])*200*1) + ((mer$Close.y[nr] - holdfx)*1000*2)) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","case3", hold,
                                maxnet, minnet,
                                mer$Close.x[nr], -mer$Close.y[nr], net))
          
          if(mer$Date[nr] == tradedate_S)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr])),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr])),use.names=F)
          }
          maxnet = 0
          minnet = 0
          lastprice = 0
          net = 0
          BS = ""
          next
        }
        
        if(net <(-30000)){
          hold = 0
          net = round(((-holdtx - mer$Close.x[nr])*200*1) + ((mer$Close.y[nr] - holdfx)*1000*2)) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","case4", hold,
                                maxnet, minnet,
                                mer$Close.x[nr], -mer$Close.y[nr], net))
          
          if(mer$Date[nr] == tradedate_S)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr])),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr])),use.names=F)
          }
          tradedate_S = mer$Date[nr]
          maxnet = 0
          minnet = 0
          lastprice = 0
          net = 0
          BS = ""
          next
        }
      }
      if(mer$Time[nr]== 132900 & !is.element(mer$Date[nr],settle_date))
      {
        if(mer$Date[nr] == tradedate_S)
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr])),use.names=F)
          
        }
        else
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr])),use.names=F)
        }
      }
    }
  }
  
  if(is.element(mer$Date[nr],settle_date) & mer$Time[nr]==132900){
    
    if(abs(hold) == 1)
    {
      
      if(BS == "BSpread"){
        hold = 0
        net = round(((mer$Close.x[nr] - holdtx)*200*1) + ((-holdfx - mer$Close.y[nr])*1000*2)) - tax
        pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","結算", hold,
                              maxnet, minnet,
                              -mer$Close.x[nr], mer$Close.y[nr],
                              net))
        
        if(mer$Date[nr] == tradedate_B)
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice)),use.names=F)
          
        }
        else
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr])),use.names=F)
        }
        maxnet = 0
        minnet = 0
        lastprice = 0
        net = 0
        BS = ""
        next
        
      }else if(BS == "SSpread"){
        hold = 0
        net = round(((-holdtx - mer$Close.x[nr])*200*1) + ((mer$Close.y[nr] - holdfx)*1000*2)) - tax
        pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","結算", hold,
                              maxnet, minnet,
                              mer$Close.x[nr], -mer$Close.y[nr],
                              net))
        
        if(mer$Date[nr] == tradedate_S)
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr])),use.names=F)
          
        }
        else
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr])),use.names=F)
        }
        maxnet = 0
        minnet = 0
        lastprice = 0
        net = 0
        BS = ""
        next
      }
    }
  }
}
##### report
pos = as.data.frame(pos)
colnames(pos) = c("Date", "time", "inout", "case", "hold",
                  "maxnet", "minnet","TXF", "EXF",'net')
pos$net = as.numeric(as.character(pos$net))
colnames(daily_profit) = c("Date", "time", "inout1",'net1')
###建構日損益
comm='台金'
st='台金1'
daily_profit$stcode =st
####################outputdata

write.csv(pos,file="//Jhpdpnas/期貨自營處/Alpha/台金電報酬圖/台金策略一.csv",row.names = F)

png(file="//Jhpdpnas/期貨自營處/Alpha/台金電報酬圖/台金策略一.png",width=2000, height=2000)
plot(cumsum(daily_profit$net1), type = "l", col = "blue",
     main = "P&L",
     ylab = "P&L")
dev.off()

tradedate_B=paste(substr(tradedate_B,start=1,stop=4),substr(tradedate_B,start=5,stop=6),substr(tradedate_B,start=7,stop=8),sep="-")
tradedate_S=paste(substr(tradedate_S,start=1,stop=4),substr(tradedate_S,start=5,stop=6),substr(tradedate_S,start=7,stop=8),sep="-")

result=data.frame("commdity"=comm,"strategy"=st,"controltype"="原始","hold"=hold,"lastdateb"=tradedate_B,"lastdates"=tradedate_S ,"lastprice"=round(lastprice),"net"=round(net),"BS"=BS,"maxnet"=round(maxnet))  

mydb2 <- dbConnect(RSQLite::SQLite(), "C:/Users/f129441027/Desktop/績效管理/策略參數管理.sqlite")
dbWriteTable(conn = mydb2,name = "策略參數", value = result , append = T)
write.csv(daily_profit , file=paste0("C:/Users/f129441027/Desktop/績效管理/策略總績效/",comm,"_",st,".csv"),row.names=F)