rm(list=ls())
library(magrittr)
library(data.table)
library(DBI) 
library(RSQLite)
# 
point = read.csv("C:/Users/f129441027/Desktop/除息/除息影響點數.csv")
point = point[c(-1), c(1,2,5)]
colnames(point) = c("Date", "txf", "tf")
point$Date = as.Date(point$Date)
point = point[order(point$Date),]
point$txf = point$txf %>% as.character() %>% as.numeric()
point$tf = point$tf %>% as.character() %>% as.numeric()

mydb <- dbConnect(RSQLite::SQLite(), "C:/Users/f129441027/Desktop/分K/_1min.sqlite")

dat1 = dbReadTable(mydb,"TSE9")
dat2 = dbReadTable(mydb,"TSEFI9")
dat1=dat1[dat1$時間>="09:00:00"&dat1$時間<="13:29:00",]
dat2=dat2[dat2$時間>="09:00:00"&dat2$時間<="13:29:00",]

dat1$時間 = gsub(":", "", dat1$時間)
dat1$時間 = gsub(" ", "", dat1$時間)
dat2 $時間 = gsub(":", "", dat2 $時間)
dat2 $時間 = gsub(" ", "", dat2 $時間)

dat=merge(dat1,dat2,by=c('日期','時間'))
dat=dat[,c(1,2,6,10)]
dat = dat[order(as.Date(dat$日期), dat$時間), ]
point_use = data.frame(Date=unique(dat$日期))
point_use$Date = as.Date(point_use$Date)


settle = read.csv("C:/Users/f129441027/Desktop/除息/結算.csv")#兩契約結算日相同
settle$Date = as.Date(settle$Date)
settle = settle[order(settle$Date),]
rownames(settle)=NULL
temp <- seq.Date(from = settle$Date[1],to= settle$Date[nrow(settle)],by = "day")
data=data.frame(Date = temp)
data=merge(data,point,by='Date',all.x=T)
data[is.na(data)] = 0


Dayreport = data.frame()
for(grp in 2:length(settle$Date)){
  subs = dplyr:: filter(data, Date > settle$Date[grp-1] & Date <= settle$Date[grp])
  subs$txf=rev(shift(cumsum(subs[order(subs$Date,decreasing = T),]$txf)))
  subs$tf=rev(shift(cumsum(subs[order(subs$Date,decreasing = T),]$tf)))
  Dayreport = rbind(Dayreport, subs)
}
Dayreport[is.na(Dayreport)] = 0
Dayreport=Dayreport[order(Dayreport$Date),]

point_use=merge(point_use,Dayreport,by="Date",all.x = T)
point_use[is.na(point_use)] = 0
point_use$Date = gsub("-", "", as.character(as.Date(point_use$Date)))
write.csv(Dayreport, file="//Jhpdpnas/期貨自營處/Alpha/台金電報酬圖/台金除息表.csv", row.names = F)
#
#
#
write.table(point_use[nrow(point_use),], file="C:/Users/f129441027/Desktop/台金data補/point_use_202010.csv", sep=",", col.names = F,row.names = F, append=TRUE)

