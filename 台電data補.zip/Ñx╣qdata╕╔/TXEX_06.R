rm(list=ls())
library(magrittr) # %>%
library(plyr) # ddply
library(dplyr) # group_by
library(fTrading)
library(roll)
library(data.table)
setwd('C:/Users/f129441027/Desktop/台電data補')
index_tx = read.csv("加權1分.csv")
index_ex = read.csv("電現1分.csv")
index_tx=index_tx[,c(1,2,6)]
index_ex=index_ex[,c(1,2,6)]

index_ex$時間 = gsub(":", "", index_ex$時間)
index_ex$時間 = gsub(" ", "", index_ex$時間)
index_tx$時間 = gsub(":", "", index_tx$時間)
index_tx$時間 = gsub(" ", "", index_tx$時間)

index_20 = merge(index_tx, index_ex, by=c("日期", "時間"), all.x = T)
colnames(index_20)=c("Date","Time","TXF","EX")
index_20 =index_20[order(as.Date(index_20$Date), index_20$Time), ]

index_20$Time = gsub(":", "", index_20$Time)
index_20$Time = gsub(" ", "", index_20$Time)

index_20$Time = as.numeric(index_20$Time)
index_20$Date = gsub("-", "", as.character(as.Date(index_20$Date)))

# 除息
point = read.csv("point_use_202010.csv")
colnames(point) = c("Date", "TXP","EXP")
# txpoint$Date=as.Date(txpoint$Date)
# mer=merge(mer,txpoint,by='Date',all.x=T)
# mer$preTX=mer$TX+mer$TXup
index_20=merge(index_20,point,by='Date',all.x=T)

index_20$TXF=index_20$TXF-index_20$TXP
index_20$EX=index_20$EX-index_20$EXP
index_20 = index_20[order(index_20$Date, index_20$Time), ]



TXF = read.csv("台期1分.csv")
EXF = read.csv("電期1分.csv")
colnames(TXF)=c("Date","Time","Open","High","Low","Close","Vol")
colnames(EXF)=c("Date","Time","Open","High","Low","Close","Vol")

TXF$Time = gsub(":", "", TXF$Time)
TXF$Time = gsub(" ", "", TXF$Time)
EXF$Time = gsub(":", "", EXF$Time)
EXF$Time = gsub(" ", "", EXF$Time)
mer = merge(TXF, EXF, by=c("Date","Time"), all=T)
mer = mer[order(as.Date(mer$Date), mer$Time), ]

mer$Date = gsub("-", "", as.Date(mer$Date))

startdate = 20150101

mer = mer[mer$Date>=startdate, ]


mer = mer[order(mer$Date, mer$Time),]
rownames(mer) = NULL


mer$fx_dif_valueori = mer$Close.x*3*200 - mer$Close.y*4*4000 
mer$thr = (mer$Close.x*3*200 - mer$Close.y*4*4000)/(mer$Close.x*3*200)
# plot(mer$Close.x[mer$Date>=20191110 & mer$Date<=20191120], type='l')
# par(mfrow=c(2,1))
# plot(mer$thr, type='l',xaxt="n")
# 
# threa =	-0.15         #契約乘數轉換日
# thrreport = mer %>% group_by(Date) %>% summarize(thrr = last(thr))
# thrreport$TXQ=ifelse(thrreport$thrr<threa,3,3)
# thrreport$EXQ=ifelse(thrreport$thrr<threa,3,4)
# plot(mer$thr,type='l')

threa =	20191104   #契約乘數轉換日
thrreport = mer %>% group_by(Date) %>% summarize(thrr = last(thr))
thrreport$TXQ=ifelse(thrreport$Date>=threa,3,3)
thrreport$EXQ=ifelse(thrreport$Date>=threa,3,4)
mer=merge(mer,thrreport,by='Date')
mer$fx_dif_value = (mer$Close.x*mer$TXQ*200) - (mer$Close.y*mer$EXQ*4000)

mer$Vol.y[is.na(mer$Vol.y)] = 0
mer$meanVol.y = shift(roll_mean(as.matrix(mer$Vol.y), 15)[, 1])*2
rownames(mer) = NULL

settle = read.csv("C:/Users/f129441027/Desktop/除息/結算.csv")
settle = settle[order(settle$Date),]
settle_date = settle$Date
settle_date = c(as.Date(settle$Date))###改
nextsettle=c(as.Date(settle$Date)+1)####改
nextsettle  = gsub("-", "", nextsettle)
settle_date = gsub("-", "", settle_date)
nextsettle = nextsettle[order(nextsettle)]
settle_date=  c(settle_date,20191101)
settle_date = settle_date[order(settle_date)]
settle = data.frame(Date=settle$Date[settle$Date>=startdate])

###############################################################################################
daydf = mer %>% group_by(Date) %>% dplyr::summarise(txdayOpen = mean(Close.x[9:16]),exdayOpen = mean(Close.y[9:16]))
mer = merge(mer, daydf, all.x=T)

mer$Time = as.numeric(mer$Time)
mer = mer[mer$Time>=90000 & mer$Time<=134400, ]

mer = merge(mer, index_20, by=c("Date", "Time"), all.x = T)

mer = mer[order(mer$Date, mer$Time),]
rownames(mer) = NULL
mer=mer[complete.cases(mer$Open.x),]

Dayreport = c()
for(grp in unique(mer$Date)){
  
  subs = dplyr:: filter(mer,Date == grp)
  Dayreport = rbind(Dayreport, list(grp,
                                    mean(subs$fx_dif_value[1:3]),
                                    last(subs$fx_dif_value),
                                    mean(subs$fx_dif_value[1:3]),
                                    max(subs$fx_dif_value[subs$Time<104000]),
                                    min(subs$fx_dif_value[subs$Time<104000])))
}

colnames(Dayreport) = c("Date", "OpenD", "CloseD", "outOpenD", "max1040D", "min1040D")
Dayreport = as.data.frame(Dayreport)
Dayreport$OpenD = as.numeric(as.character(Dayreport$OpenD))
Dayreport$CloseD = as.numeric(as.character(Dayreport$CloseD))
Dayreport$outOpenD = as.numeric(as.character(Dayreport$outOpenD))
Dayreport$max1040D = as.numeric(as.character(Dayreport$max1040D))
Dayreport$min1040D = as.numeric(as.character(Dayreport$min1040D))
Dayreport$LS = ifelse(Dayreport$CloseD - Dayreport$OpenD > 0, 1, 0)

mer$speed = ((mer$Close.x-mer$txdayOpen)/mer$txdayOpen)-((mer$Close.y-mer$exdayOpen)/mer$exdayOpen)    

mer$txdiff = ((mer$Close.x - mer$TXF) / mer$TXF)
mer$exdiff = ((mer$Close.y - mer$EX) / mer$EX)
mer$tediff = mer$txdiff - mer$exdiff

fun1 = function(a){max(subs$tediff[1:a])}
fun2 = function(a){min(subs$tediff[1:a])}

dailyrollhigh = c()
dailyrolllow = c()
for(grp in unique(mer$Date))
{
  
  subs = dplyr::filter(mer, Date == grp)
  dailyrollhigh = c(dailyrollhigh, sapply(1:nrow(subs), fun1))
  dailyrolllow = c(dailyrolllow, sapply(1:nrow(subs), fun2))
}

mer = cbind(mer, dailyrollhigh, dailyrolllow)
mer$drawdown=(mer$dailyrollhigh-mer$tediff)
mer$drawup=(mer$tediff-mer$dailyrolllow)

rownames(mer) = NULL
mer = mer[mer$Time <= 132900, ]
laclose = mer %>% group_by(Date) %>% slice(n())
laclose = laclose[,c(1,18)]
laclose$fx_dif_value=shift(laclose$fx_dif_value)
colnames(laclose)=c("Date","lavalue")
mer =left_join(mer,laclose,by="Date")
mer = mer[!is.na(mer$lavalue),]

########################################
mer=mer[!is.element(mer$Date,nextsettle),]
tax = 400 * 7
pos = data.frame()
daily_profit=data.table()

hold = 0
maxnet = 0
minnet = 0
firsts = as.numeric(table(mer$Date)[1])
tradedate_B = 20181218
tradedate_S = 20181218
netlimit=20000
speed_thr = 0.001
speed_thr2 = 0
for (nr in 808:nrow(mer)) {
  
  if(hold == 0 & mer$Time[nr]>=90500 & mer$Time[nr]<= 132400){
    # case1:進場 # 買台空電
    if(tradedate_B!=mer$Date[nr] & mer$speed[nr]>speed_thr2 & mer$speed[nr-1]>speed_thr2 & mer$tediff[nr]<0 & mer$tediff[nr-1]<0 & mer$dailyrollhigh[nr]-mer$dailyrolllow[nr] >0.0025){
      
      hold = 1
      BS = "BS"
      holdtx = mer$Close.x[nr]
      holdex = -mer$Close.y[nr]
      tradedate_B = mer$Date[nr]
      lastprice=mer$fx_dif_value[nr]

      pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_in", "進場", hold,
                            0, 0,
                            holdtx, holdex, 0))
      next
      
      # case1:進場     
    }
    else if(tradedate_S!=mer$Date[nr] & mer$speed[nr]<((-1)*speed_thr2) & mer$speed[nr-1]<((-1)*speed_thr2) & mer$tediff[nr]>0 & mer$tediff[nr-1]>0 & mer$dailyrollhigh[nr]-mer$dailyrolllow[nr] >0.0025){
      # 空台買電
      
      hold = 1
      BS = "SB"
      holdtx =  -mer$Close.x[nr]
      holdex =  mer$Close.y[nr]
      tradedate_S = mer$Date[nr]
      lastprice=mer$fx_dif_value[nr]

      pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_in", "進場", hold,
                            0, 0,
                            holdtx, holdex, 0))
      next
      
    }
  }
  
  if(hold == 1){
    
    whdayreport = which(mer$Date[nr] == Dayreport$Date)
    if(BS == "BS"){
      
      net = round((mer$Close.x[nr] - holdtx)*200*mer$TXQ[nr] + (-holdex - mer$Close.y[nr])*4000*mer$EXQ[nr]) - tax
      maxnet = max(maxnet, net)
      minnet = min(minnet, net)

      if(mer$Time[nr]>=90500 & mer$Time[nr]<= 132900)
      {
        if(mer$Date[nr] != tradedate_B & Dayreport$outOpenD[whdayreport]<Dayreport$CloseD[whdayreport-1]-7000 & mer$speed[nr]<((-1)*speed_thr)){
          
          hold = 0
          net = round((mer$Close.x[nr] - holdtx)*200*mer$TXQ[nr] + (-holdex - mer$Close.y[nr])*4000*mer$EXQ[nr]) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","case2", hold,
                                maxnet, minnet,
                                -mer$Close.x[nr], mer$Close.y[nr], net))
          if(mer$Date[nr] == tradedate_B)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice-tax)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr]-tax)),use.names=F)
          }
          maxnet = 0
          minnet = 0
          next
        }
        
        if(net < (-40000)){
          
          hold = 0
          net = round((mer$Close.x[nr] - holdtx)*200*mer$TXQ[nr] + (-holdex - mer$Close.y[nr])*4000*mer$EXQ[nr]) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","case5", hold,
                                maxnet, minnet,
                                -mer$Close.x[nr], mer$Close.y[nr], net))
          
          if(mer$Date[nr] == tradedate_B)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice-tax)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr]-tax)),use.names=F)
          }
          maxnet = 0
          minnet = 0
          next
        }
        
        if(mer$Date[nr] != tradedate_B & mer$Time[nr]>=104000 & Dayreport$CloseD[whdayreport-1] > Dayreport$max1040D[whdayreport]){

          hold = 0
          net = round((mer$Close.x[nr] - holdtx)*200*mer$TXQ[nr] + (-holdex - mer$Close.y[nr])*4000*mer$EXQ[nr]) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","case3", hold,
                                maxnet, minnet,
                                -mer$Close.x[nr], mer$Close.y[nr], net))
          if(mer$Date[nr] == tradedate_B)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice-tax)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr]-tax)),use.names=F)
          }
          tradedate_B = mer$Date[nr]
          maxnet = 0
          minnet = 0
          next
        }
        if(mer$speed[nr]<((-1)*speed_thr)  & mer$speed[nr-1]<((-1)*speed_thr) & mer$tediff[nr]>0 & mer$tediff[nr-1]>0 & mer$Time[nr]<= 132400){

          hold = 0
          net = round((mer$Close.x[nr] - holdtx)*200*mer$TXQ[nr] + (-holdex - mer$Close.y[nr])*4000*mer$EXQ[nr]) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","case3", hold,
                                maxnet, minnet,
                                -mer$Close.x[nr], mer$Close.y[nr], net))
          if(mer$Date[nr] == tradedate_B)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice-tax)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr]-tax)),use.names=F)
          }
          tradedate_B = mer$Date[nr]
          maxnet = 0
          minnet = 0
          next
        }
        if(maxnet>=40000 & net <= maxnet-netlimit){
          hold = 0
          net = round((mer$Close.x[nr] - holdtx)*200*mer$TXQ[nr] + (-holdex - mer$Close.y[nr])*4000*mer$EXQ[nr]) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","case6", hold,
                                maxnet, minnet,
                                -mer$Close.x[nr], mer$Close.y[nr], net))
          if(mer$Date[nr] == tradedate_B)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice-tax)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr]-tax)),use.names=F)
          }
          tradedate_B = mer$Date[nr]
          maxnet = 0
          minnet = 0
          next
        }
      }
      if(mer$Time[nr]== 132900 & !is.element(mer$Date[nr],settle_date))
      {
        if(mer$Date[nr] == tradedate_B)
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice)),use.names=F)
          
        }
        else
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr])),use.names=F)
        }
      }
    }
    
    if(BS == "SB"){
      
      net = round((-holdtx - mer$Close.x[nr])*200*mer$TXQ[nr] + (mer$Close.y[nr] - holdex)*4000*mer$EXQ[nr]) - tax
      maxnet = max(maxnet, net)
      minnet = min(minnet, net)
      if(mer$Time[nr]>=90500 & mer$Time[nr]<= 132900)
      {
        
        if(mer$Date[nr] != tradedate_S & Dayreport$outOpenD[whdayreport]>Dayreport$CloseD[whdayreport-1]+7000 & mer$speed[nr]>speed_thr){
          hold = 0
          net = round((-holdtx - mer$Close.x[nr])*200*mer$TXQ[nr] + (mer$Close.y[nr] - holdex)*4000*mer$EXQ[nr]) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","case2", hold,
                                maxnet, minnet,
                                mer$Close.x[nr],-mer$Close.y[nr], net))
          if(mer$Date[nr] == tradedate_S)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr]-tax)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr]-tax)),use.names=F)
          }
          maxnet = 0
          minnet = 0
          next
        }
        
        if(net <(-40000)){
          hold = 0
          net = round((-holdtx - mer$Close.x[nr])*200*mer$TXQ[nr] + (mer$Close.y[nr] - holdex)*4000*mer$EXQ[nr]) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","case5", hold,
                                maxnet, minnet,
                                mer$Close.x[nr], -mer$Close.y[nr], net))
          if(mer$Date[nr] == tradedate_S)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr]-tax)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr]-tax)),use.names=F)
          }
          maxnet = 0
          minnet = 0
          next
        }
        
        if(mer$Date[nr] != tradedate_S & mer$Time[nr]>=104000 & Dayreport$CloseD[whdayreport-1] < Dayreport$min1040D[whdayreport]){
          hold = 0
          net = round((-holdtx - mer$Close.x[nr])*200*mer$TXQ[nr] + (mer$Close.y[nr] - holdex)*4000*mer$EXQ[nr]) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","case3", hold,
                                maxnet, minnet,
                                mer$Close.x[nr], -mer$Close.y[nr], net))
          if(mer$Date[nr] == tradedate_S)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr]-tax)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr]-tax)),use.names=F)
          }
          tradedate_S = mer$Date[nr]
          maxnet = 0
          minnet = 0
          next
        }
        
        if(mer$speed[nr]>speed_thr & mer$speed[nr-1]>speed_thr & mer$tediff[nr]<0 & mer$tediff[nr-1]<0 & mer$Time[nr]<= 132400){

          hold = 0
          net = round((-holdtx - mer$Close.x[nr])*200*mer$TXQ[nr] + (mer$Close.y[nr] - holdex)*4000*mer$EXQ[nr]) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","case3", hold,
                                maxnet, minnet,
                                mer$Close.x[nr], -mer$Close.y[nr], net))
          if(mer$Date[nr] == tradedate_S)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr]-tax)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr]-tax)),use.names=F)
          }
          tradedate_S = mer$Date[nr]
          maxnet = 0
          minnet = 0
          next
        }
        if(maxnet >= 40000 & net <= maxnet-netlimit){
          hold = 0

          net = round((-holdtx - mer$Close.x[nr])*200*mer$TXQ[nr] + (mer$Close.y[nr] - holdex)*4000*mer$EXQ[nr]) - tax
          pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","case6", hold,
                                maxnet, minnet,
                                mer$Close.x[nr], -mer$Close.y[nr], net))
          if(mer$Date[nr] == tradedate_S)
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr]-tax)),use.names=F)
            
          }
          else
          {
            daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr]-tax)),use.names=F)
          }
          tradedate_S = mer$Date[nr]
          maxnet = 0
          minnet = 0
          next
        }
      }
      if(mer$Time[nr]== 132900 & !is.element(mer$Date[nr],settle_date))
      {
        if(mer$Date[nr] == tradedate_S)
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr])),use.names=F)
          
        }
        else
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr])),use.names=F)
        }
      }
    }
  }
  
  if(is.element(mer$Date[nr],settle_date) & mer$Time[nr]==132900){
    
    if(hold == 1){
      
      if(BS == "BS"){
        hold = 0
        net = round((mer$Close.x[nr] - holdtx)*200*mer$TXQ[nr]+ (-holdex - mer$Close.y[nr])*4000*mer$EXQ[nr]) - tax
        pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "BS_out","結算", hold,
                              maxnet, minnet,
                              -mer$Close.x[nr], mer$Close.y[nr],
                              net))
        if(mer$Date[nr] == tradedate_B)
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-lastprice-tax)),use.names=F)
          
        }
        else
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "BS_out",mer$fx_dif_value[nr]-mer$lavalue[nr]-tax)),use.names=F)
        }
        maxnet = 0
        minnet = 0
        next
        
      }else if(BS == "SB"){
        hold = 0
        net = round((-holdtx - mer$Close.x[nr])*200*mer$TXQ[nr] + (mer$Close.y[nr] - holdex)*4000*mer$EXQ[nr]) - tax
        pos = rbind(pos, list(mer$Date[nr], mer$Time[nr], "SB_out","結算", hold,
                              maxnet, minnet,
                              mer$Close.x[nr], -mer$Close.y[nr],
                              net))
        if(mer$Date[nr] == tradedate_S)
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",lastprice-mer$fx_dif_value[nr]-tax)),use.names=F)
          
        }
        else
        {
          daily_profit = rbindlist(list(daily_profit, list(mer$Date[nr], mer$Time[nr], "SB_out",mer$lavalue[nr]-mer$fx_dif_value[nr]-tax)),use.names=F)
        }
        maxnet = 0
        minnet = 0
        next
      }
    }
  }
}

##### report
pos = as.data.frame(pos)
colnames(pos) = c("Date", "time", "inout", "case", "hold",
                  "maxnet", "minnet","TXF", "EXF",'net')
pos$net = as.numeric(as.character(pos$net))
colnames(daily_profit) = c("Date", "time", "inout1",'net1')
sum(pos$net)
sum(daily_profit$net1)

write.csv(pos,file="//Jhpdpnas/期貨自營處/Alpha/台金電報酬圖/台電策略六.csv",row.names = F)
png(file="//Jhpdpnas/期貨自營處/Alpha/台金電報酬圖/台電策略六.png",width=2000, height=2000)
plot(cumsum(pos$net[pos$net!=0]), type = "l", col = "blue",
     main = "P&L",
     ylab = "P&L")
dev.off()

result=list(hold,tradedate_B,tradedate_S,lastprice,net,BS,length(pos$net[pos$net!=0]),sum(pos$net[pos$net!=0]),maxDrawDown(cumsum(pos$net[pos$net!=0])),sum(pos$net[pos$net!=0]>0) / length(pos$net[pos$net!=0]))
write.csv(result,file='策略六.csv',row.names = F)


daily_profit$stcode ='electric6'
daily_profit$net1=daily_profit$net1/3
write.csv(daily_profit,file='C:/Users/f129441027/Desktop/績效管理/台電/st6traderecord.csv',row.names = F)