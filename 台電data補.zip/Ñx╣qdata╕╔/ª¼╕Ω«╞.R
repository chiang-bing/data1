rm(list=ls())
library(TTR)
library(magrittr) # %>%
library(plyr) # ddply
library(dplyr)
library(ggplot2)
library(data.table)
library(TimeWarp)
library(DBI) 
library(RSQLite)
library(lubridate)
# #####電期2018 台期2018  金期2019/2/11
setwd("//10.99.103.160/資料儲存/DataTemp")
mydb <- dbConnect(RSQLite::SQLite(), "C:/Users/f129441027/Desktop/分k/_1min.sqlite")
file=list.files()
file=file[!is.element(file,"最後更新時間.sqlite") ]
for(grp1 in file)
{
  tempdb <- dbConnect(RSQLite::SQLite(),grp1)
  ll = dbListTables(tempdb)
  tempdd = dbReadTable(conn = tempdb,ll[length(ll)-1])
  outdd = tempdd[as.Date(tempdd$Date) == Sys.Date() ,]
  colnames(outdd)=c("日期","時間","開盤價","最高價","最低價","收盤價","成交量")
  outdd$時間=format(as.POSIXct(paste(outdd$日期,outdd$時間))- minutes(1),"%H:%M:%S")
  if(nrow(outdd) >0 )
  {
    dbWriteTable(conn = mydb,name = unlist(strsplit(grp1,"[.]"))[1], value = outdd , append = T)
  }
}