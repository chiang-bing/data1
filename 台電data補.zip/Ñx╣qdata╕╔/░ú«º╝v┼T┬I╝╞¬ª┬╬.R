rm(list=ls())
library(magrittr) 
library(plyr) # ddply
library(dplyr) # group_by
library(fTrading)
library(data.table)
library(ggplot2)
library(httr)
library(rvest)
library(zoo)
library(DBI)
library(RSQLite)
library(lubridate)
library(tidyr)

url2 = paste0("https://histock.tw/stock/exdividendpoint.aspx")
response2 = httr::GET(url = url2)
data2 = read_html(response2)
df2 = data2 %>% html_nodes(css='div.grid-body tr')
final=data.frame()
for (nr2 in 3:length(df2))
{
  list=c(df2[nr2] %>% html_nodes(css='th') %>% html_text(),df2[nr2] %>% html_nodes(css='td') %>% html_text())
  final = rbind(final,list)
}
final = final[,c(1,2,4,6,8,10,12)]
colnames(final)=c("商品名稱","加權指數","櫃買","電子","金融","非金電","摩台指")
point = read.csv("C:/Users/f129441027/Desktop/除息/除息影響點數.csv")
point = point[!is.element(as.Date(point$商品名稱),as.Date(final$商品名稱)),]
point=rbind(point,final)
write.csv(point,"C:/Users/f129441027/Desktop/除息/除息影響點數.csv",row.names=F)